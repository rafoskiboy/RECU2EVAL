using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlyingEnemy : MonoBehaviour
{
    public float speed = 2f;
    public float directionChangeInterval = 5f;
    private float direction = 1f;
    private float timerDirection;
    

    
    // Start is called before the first frame update
    void Start()
    {
        timerDirection = directionChangeInterval;

    }

    // Update is called once per frame
    void Update()
    {
       transform.Translate(new Vector2(direction * speed * Time.deltaTime, 0));

        timerDirection -= Time.deltaTime;

        if (timerDirection <= 0) 
        {
            direction *= -1;
            timerDirection = directionChangeInterval;
        }
    }
}
